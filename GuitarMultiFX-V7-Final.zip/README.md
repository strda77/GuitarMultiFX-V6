# GuitarMultiFX V7

Android guitar multi-effects prototype/final test build for 48 kHz mono real-time processing.

## Features
- 48 kHz / 256-sample processing path
- 36 factory-style starter presets
- Gate, compressor, drive, amp coloration, cab simulation, 3-band EQ
- Chorus, phaser, flanger, delay and reverb
- 180-second looper: REC / PLAY / DUB / CLEAR
- Pitch tuner with note + cents
- Tap tempo
- User SAVE / LOAD
- WAV impulse-response loader (16-bit PCM WAV, first 128 samples used as FIR)
- Landscape pedalboard UI designed for phone use
- USB audio interface can be used when Android exposes it as the input/output route

## Build on GitHub Actions
Push these files to the repository's `main` branch, or run the workflow manually from Actions.
Artifact: `GuitarMultiFX-V7-APK`.

## Important
This is a real-time DSP prototype and should be tested with headphones and a USB audio interface. Bluetooth monitoring can add substantial latency.
