package com.strada.guitarmultifx;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int SR=48000, BS=256, PERM=10, PICK_IR=11;
    AudioRecord rec; AudioTrack play; Thread audioThread; volatile boolean running;
    volatile float level, frequency, cents; volatile String note="--";
    TextView presetTitle,status,tuner,tempoText,irText; ProgressBar meter; LinearLayout effectsRow;
    final DSP dsp=new DSP();
    int presetIndex=0, bpm=120;

    final String[] presets={
      "GLASS CLEAN","CHIME POP","FUNK CLEAN","ACOUSTIC","BLUES DRIVER","TEXAS BLUES",
      "SRV BLUES","BLUES LEAD","CLASSIC ROCK","AC/DC STYLE","80S ROCK","ROCK LEAD",
      "METAL RHYTHM","TIGHT METAL","MODERN METAL","METAL LEAD","SINGING LEAD","80S SOLO",
      "AMBIENT CLEAN","SPACE GUITAR","DREAM","REVERSE SPACE","FUNK WAH","TALKING WAH",
      "OCTAVE SOLO","PITCH SOLO","CHORUS CLEAN","PHASER ROCK","ROTARY","FLANGER",
      "SOLO BOOST","RHYTHM SOLO","CLEAN CRUNCH","FINAL STAGE","DARK AMBIENT","DJENT TIGHT"
    };
    final String[] fxNames={"GATE","COMP","DRIVE","AMP","CAB","CHORUS","PHASER","FLANGER","DELAY","REVERB","IR","BYPASS"};

    @Override public void onCreate(Bundle b){
      super.onCreate(b);
      buildUI(getSharedPreferences("guitar_fx",MODE_PRIVATE));
    }

    TextView tv(String s,float sp){
      TextView t=new TextView(this); t.setText(s); t.setTextSize(sp);
      t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER); return t;
    }
    Button btn(String s){
      Button b=new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false);
      b.setMinHeight(0); b.setMinWidth(0); b.setPadding(8,2,8,2); return b;
    }
    LinearLayout box(){
      LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
      l.setPadding(6,4,6,4); l.setBackgroundColor(Color.rgb(25,25,29)); return l;
    }

    void buildUI(SharedPreferences p){
      LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
      root.setPadding(8,5,8,5); root.setBackgroundColor(Color.rgb(8,9,11));

      LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
      presetTitle=tv(presets[0],20); top.addView(presetTitle,new LinearLayout.LayoutParams(0,58,1));
      status=tv("STOPPED",12); top.addView(status,new LinearLayout.LayoutParams(110,58));
      Button start=btn("START"); Button stop=btn("STOP");
      top.addView(start,new LinearLayout.LayoutParams(90,58));
      top.addView(stop,new LinearLayout.LayoutParams(80,58));
      Button save=btn("SAVE"); Button load=btn("LOAD");
      top.addView(save,new LinearLayout.LayoutParams(80,58));
      top.addView(load,new LinearLayout.LayoutParams(80,58));
      root.addView(top);

      LinearLayout info=new LinearLayout(this);
      tuner=tv("TUNER  --",20); info.addView(tuner,new LinearLayout.LayoutParams(0,48,1));
      meter=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); meter.setMax(1000);
      info.addView(meter,new LinearLayout.LayoutParams(0,28,1));
      tempoText=tv("BPM 120",14); info.addView(tempoText,new LinearLayout.LayoutParams(110,48));
      Button tap=btn("TAP"); info.addView(tap,new LinearLayout.LayoutParams(75,48));
      root.addView(info);

      LinearLayout presetRow=new LinearLayout(this);
      for(int i=0;i<presets.length;i++){
        final int n=i; Button b=btn((i+1)+" "+presets[i]);
        b.setOnClickListener(v->{presetIndex=n; applyPreset(n);});
        presetRow.addView(b,new LinearLayout.LayoutParams(150,54));
      }
      HorizontalScrollView ps=new HorizontalScrollView(this); ps.setHorizontalScrollBarEnabled(false);
      ps.addView(presetRow); root.addView(ps,new LinearLayout.LayoutParams(-1,60));

      effectsRow=new LinearLayout(this); effectsRow.setOrientation(LinearLayout.HORIZONTAL);
      HorizontalScrollView fxScroll=new HorizontalScrollView(this); fxScroll.setHorizontalScrollBarEnabled(false);
      fxScroll.addView(effectsRow); root.addView(fxScroll,new LinearLayout.LayoutParams(-1,0,1));

      LinearLayout bottom=new LinearLayout(this);
      Button recB=btn("● REC"), playB=btn("▶ PLAY"), dubB=btn("DUB"), clearB=btn("CLEAR");
      Button bypass=btn("BYPASS"), loadIr=btn("LOAD IR");
      bottom.addView(recB,new LinearLayout.LayoutParams(0,55,1));
      bottom.addView(playB,new LinearLayout.LayoutParams(0,55,1));
      bottom.addView(dubB,new LinearLayout.LayoutParams(0,55,1));
      bottom.addView(clearB,new LinearLayout.LayoutParams(0,55,1));
      bottom.addView(bypass,new LinearLayout.LayoutParams(0,55,1));
      bottom.addView(loadIr,new LinearLayout.LayoutParams(0,55,1));
      root.addView(bottom);
      irText=tv("IR: built-in cab",12); root.addView(irText,new LinearLayout.LayoutParams(-1,28));

      buildEffectCards();
      setContentView(root);

      start.setOnClickListener(v->requestAudio());
      stop.setOnClickListener(v->{stopAudio();status.setText("STOPPED");});
      save.setOnClickListener(v->{saveUser();status.setText("USER SAVED");});
      load.setOnClickListener(v->{loadUser();status.setText("USER LOADED");});
      tap.setOnClickListener(v->{bpm+=5;if(bpm>180)bpm=60;tempoText.setText("BPM "+bpm);dsp.bpm=bpm;});
      recB.setOnClickListener(v->{dsp.loopStartRecord();status.setText("LOOP REC");});
      playB.setOnClickListener(v->{dsp.loopPlay();status.setText("LOOP PLAY");});
      dubB.setOnClickListener(v->{dsp.loopDub();status.setText("LOOP DUB");});
      clearB.setOnClickListener(v->{dsp.loopClear();status.setText("LOOP CLEAR");});
      bypass.setOnClickListener(v->{dsp.bypass=!dsp.bypass;status.setText(dsp.bypass?"BYPASS ON":"BYPASS OFF");});
      loadIr.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/wav");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_IR);});
      applyPreset(0);
      new Handler().postDelayed(new Runnable(){public void run(){uiTick();}},100);
    }

    void buildEffectCards(){
      effectsRow.removeAllViews();
      for(int i=0;i<fxNames.length;i++){
        final int id=i; LinearLayout c=box(); TextView title=tv(fxNames[i],13);
        c.addView(title,new LinearLayout.LayoutParams(120,35));
        Button on=btn(dsp.enabled[i]?"ON":"OFF"); c.addView(on,new LinearLayout.LayoutParams(120,42));
        on.setOnClickListener(v->{dsp.enabled[id]=!dsp.enabled[id];on.setText(dsp.enabled[id]?"ON":"OFF");});
        if(i==2||i==3||i==4||i==8||i==9||i==5||i==6||i==7){
          SeekBar s=new SeekBar(this); s.setMax(100); s.setProgress(dsp.fxAmount(i));
          c.addView(s,new LinearLayout.LayoutParams(120,48));
          TextView val=tv(""+dsp.fxAmount(i),11); c.addView(val,new LinearLayout.LayoutParams(120,25));
          s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){dsp.setFxAmount(id,p);val.setText(""+p);}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
          });
        }
        effectsRow.addView(c,new LinearLayout.LayoutParams(130,175));
      }
    }

    void applyPreset(int n){ presetTitle.setText(presets[n]); dsp.resetPreset(n,bpm); buildEffectCards(); }
    void saveUser(){ dsp.save(getSharedPreferences("guitar_fx",MODE_PRIVATE).edit()); }
    void loadUser(){ dsp.load(getSharedPreferences("guitar_fx",MODE_PRIVATE)); buildEffectCards(); }

    void requestAudio(){
      if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},PERM); return;
      }
      startAudio();
    }

    void startAudio(){
      if(running)return;
      try{
        int inMin=AudioRecord.getMinBufferSize(SR,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        int outMin=AudioTrack.getMinBufferSize(SR,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
        int bs=Math.max(4096,Math.max(inMin,outMin));
        rec=new AudioRecord.Builder()
          .setAudioSource(MediaRecorder.AudioSource.DEFAULT)
          .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
          .setBufferSizeInBytes(bs).build();
        play=new AudioTrack.Builder()
          .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
          .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
          .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(bs).build();
        rec.startRecording(); play.play(); running=true; status.setText("AUDIO RUNNING");
        audioThread=new Thread(this::audioLoop,"GuitarAudio"); audioThread.start();
      }catch(Exception e){status.setText("AUDIO ERROR");stopAudio();}
    }

    void audioLoop(){
      Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
      short[] in=new short[BS],out=new short[BS];
      float[] block=new float[BS];
      while(running){
        int n=rec.read(in,0,BS,AudioRecord.READ_BLOCKING); if(n<=0)continue;
        level=dsp.peak(in,n); dsp.detect(in,n);
        for(int i=0;i<n;i++) block[i]=dsp.process(in[i]/32768f);
        dsp.loopProcess(block,n);
        for(int i=0;i<n;i++) out[i]=(short)(block[i]*32767f);
        play.write(out,0,n,AudioTrack.WRITE_BLOCKING);
      }
    }

    void stopAudio(){
      running=false;
      try{if(rec!=null)rec.stop();}catch(Exception e){}
      try{if(play!=null)play.stop();}catch(Exception e){}
      if(rec!=null)rec.release(); if(play!=null)play.release(); rec=null; play=null;
    }

    void uiTick(){
      if(isFinishing())return;
      meter.setProgress((int)Math.min(1000,level*1000));
      if(frequency>0)tuner.setText("TUNER  "+note+"  "+(cents>=0?"+":"")+(int)cents+"c");
      else tuner.setText("TUNER  --");
      new Handler().postDelayed(()->uiTick(),100);
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
      super.onRequestPermissionsResult(r,p,g);
      if(r==PERM&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startAudio();
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
      super.onActivityResult(r,c,d);
      if(r==PICK_IR&&c==RESULT_OK&&d!=null){
        try{dsp.loadWav(getContentResolver().openInputStream(d.getData()));irText.setText("IR: "+d.getData().getLastPathSegment());}
        catch(Exception e){irText.setText("IR: load failed");}
      }
    }

    @Override protected void onDestroy(){stopAudio();super.onDestroy();}

    class DSP {
      boolean[] enabled={true,true,true,true,true,true,true,true,true,true,false,false};
      boolean bypass=false; int bpm=120;
      float gate=-48,comp=45,drive=0,tone=55,ampGain=45,bass=50,mid=50,treble=55,cab=60,chorus=20,phaser=0,flanger=0,delay=15,reverb=12;
      float[] z1=new float[2],z2=new float[2]; float prevIn=0,env=0,lowEq=0;
      float[] delayBuf=new float[SR*2]; int delayPos;
      float[] chBuf=new float[SR]; int chPos; float[] flBuf=new float[SR]; int flPos;
      float[] comb1=new float[1550],comb2=new float[1617],comb3=new float[1490],comb4=new float[1277];
      int c1,c2,c3,c4;
      float[] loop=new float[SR*180]; int loopLen=0,loopPos=0,loopMode=0;
      float[] fir=new float[128],firHist=new float[128]; int firPos=0; boolean irLoaded=false;
      float phaserState=0,chorusPhase=0,flangePhase=0;
      float[] pitchBuf=new float[2048];int pitchPos=0,pitchCount=0;long lastPitch=0;

      void resetPreset(int n,int bpm0){
        bpm=bpm0;bypass=false;Arrays.fill(enabled,true);enabled[10]=false;enabled[11]=false;
        drive=0;gate=-48;comp=45;tone=55;ampGain=45;bass=50;mid=50;treble=55;cab=60;chorus=0;phaser=0;flanger=0;delay=10;reverb=10;
        switch(n){
          case 0:ampGain=28;treble=65;cab=45;chorus=18;delay=12;reverb=18;break;
          case 1:ampGain=35;treble=70;cab=48;chorus=25;delay=15;reverb=15;break;
          case 2:ampGain=22;bass=42;mid=48;treble=68;chorus=30;reverb=12;break;
          case 3:ampGain=25;bass=45;mid=52;treble=64;reverb=20;break;
          case 4:drive=35;ampGain=48;mid=60;treble=58;cab=50;delay=12;reverb=14;break;
          case 5:drive=52;ampGain=60;mid=65;treble=60;cab=58;reverb=12;break;
          case 6:drive=45;ampGain=55;mid=72;treble=56;reverb=16;delay=14;break;
          case 7:drive=58;ampGain=62;mid=70;treble=60;delay=22;reverb=18;break;
          case 8:drive=48;ampGain=60;mid=68;treble=60;cab=60;reverb=10;break;
          case 9:drive=65;ampGain=72;mid=64;treble=66;gate=-38;cab=70;reverb=8;break;
          case 10:drive=70;ampGain=74;mid=72;treble=62;delay=25;reverb=20;break;
          case 11:drive=56;ampGain=68;mid=76;treble=64;delay=28;reverb=20;break;
          case 12:drive=72;ampGain=75;mid=42;treble=72;gate=-34;cab=72;reverb=6;break;
          case 13:drive=66;ampGain=72;mid=35;treble=74;gate=-32;cab=75;break;
          case 14:drive=80;ampGain=78;mid=30;treble=76;gate=-30;cab=80;reverb=5;break;
          case 15:drive=72;ampGain=74;mid=48;treble=70;gate=-32;delay=24;reverb=14;break;
          case 16:drive=60;ampGain=70;mid=74;treble=62;delay=30;reverb=18;break;
          case 17:drive=64;ampGain=72;mid=70;treble=68;chorus=18;delay=32;reverb=22;break;
          case 18:ampGain=30;chorus=35;delay=32;reverb=40;break;
          case 19:ampGain=28;chorus=30;delay=38;reverb=55;break;
          case 20:ampGain=42;chorus=28;delay=40;reverb=58;break;
          case 21:ampGain=30;phaser=30;delay=38;reverb=65;break;
          case 22:ampGain=25;chorus=20;delay=8;reverb=15;break;
          case 23:drive=30;ampGain=40;delay=18;reverb=16;break;
          case 24:drive=50;ampGain=58;mid=70;delay=28;reverb=20;break;
          case 25:drive=55;ampGain=62;mid=72;delay=30;reverb=22;break;
          case 26:ampGain=30;chorus=42;delay=18;reverb=25;break;
          case 27:drive=35;ampGain=55;phaser=48;delay=15;reverb=15;break;
          case 28:ampGain=25;chorus=25;reverb=22;break;
          case 29:ampGain=38;flanger=48;delay=16;reverb=18;break;
          case 30:drive=58;ampGain=68;mid=78;treble=64;delay=34;reverb=20;break;
          case 31:drive=40;ampGain=60;mid=72;delay=24;reverb=18;break;
          case 32:drive=18;ampGain=42;mid=58;chorus=18;delay=15;reverb=16;break;
          case 33:drive=50;ampGain=65;mid=70;delay=32;reverb=22;break;
          case 34:ampGain=34;bass=58;mid=42;treble=50;delay=38;reverb=50;break;
          case 35:drive=78;ampGain=76;bass=64;mid=28;treble=75;gate=-29;cab=80;break;
        }
      }

      int fxAmount(int i){
        switch(i){case 2:return(int)drive;case 3:return(int)ampGain;case 4:return(int)cab;case 5:return(int)chorus;
          case 6:return(int)phaser;case 7:return(int)flanger;case 8:return(int)delay;case 9:return(int)reverb;default:return 0;}
      }
      void setFxAmount(int i,int p){
        switch(i){case 2:drive=p;break;case 3:ampGain=p;break;case 4:cab=p;break;case 5:chorus=p;break;
          case 6:phaser=p;break;case 7:flanger=p;break;case 8:delay=p;break;case 9:reverb=p;break;}
      }

      float peak(short[] a,int n){int pk=0;for(int i=0;i<n;i++)pk=Math.max(pk,Math.abs((int)a[i]));return pk/32767f;}

      void detect(short[] a,int n){
        for(int i=0;i<n;i++){pitchBuf[pitchPos]=a[i]/32768f;pitchPos=(pitchPos+1)%pitchBuf.length;if(pitchCount<pitchBuf.length)pitchCount++;}
        long now=System.currentTimeMillis();if(now-lastPitch<90||pitchCount<1024)return;lastPitch=now;
        int N=1024;float[] x=new float[N];for(int i=0;i<N;i++)x[i]=pitchBuf[(pitchPos-N+i+pitchBuf.length)%pitchBuf.length];
        float rms=0;for(float v:x)rms+=v*v;if(Math.sqrt(rms/N)<.012){frequency=0;return;}
        int bestLag=0;double best=-1;
        for(int lag=35;lag<=600;lag++){double c=0;for(int i=0;i<N-lag;i++)c+=x[i]*x[i+lag];if(c>best){best=c;bestLag=lag;}}
        if(bestLag==0)return;
        frequency=SR/(float)bestLag;int midi=(int)Math.round(69+12*Math.log(frequency/440.0)/Math.log(2));
        double target=440*Math.pow(2,(midi-69)/12.0);cents=(float)(1200*Math.log(frequency/target)/Math.log(2));
        String[] ns={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};note=ns[(midi%12+12)%12]+(midi/12-1);
      }

      float process(float x){
        if(bypass)return x;
        float dry=x;
        if(enabled[0]){float a=Math.abs(x),th=(float)Math.pow(10,gate/20);if(a<th)x*=a/(th+1e-5f);}
        if(enabled[1]){float e=Math.abs(x);env=env*.995f+e*.005f;float target=env>.25f?1f:1f/(1f+comp/70f);x*=target;}
        if(enabled[2]&&drive>0){float g=1f+drive*.09f;x=(float)Math.tanh(x*g);x*=1f+drive*.006f;}
        if(enabled[3])x=amp(x);
        if(enabled[4])x=cab(x);
        x=eq(x);
        if(enabled[10]&&irLoaded)x=ir(x);
        if(enabled[5]&&chorus>0)x=chorus(x);
        if(enabled[6]&&phaser>0)x=phaser(x);
        if(enabled[7]&&flanger>0)x=flanger(x);
        if(enabled[8]&&delay>0)x=delay(x);
        if(enabled[9]&&reverb>0)x=reverb(x);
        return clamp(x*.92f+dry*.08f);
      }

      float amp(float x){float g=1+ampGain*.045f;x=(float)Math.tanh(x*g);float hp=x-prevIn*.985f;prevIn=x;float t=treble/100f;return hp*(.55f+.65f*t);}
      float cab(float x){float a=cab/100f;z1[0]=z1[0]*.96f+x*.04f;float h=x-z1[0];return z1[0]*(.55f+.55f*a)+h*(.25f-.12f*a);}
      float eq(float x){float t=treble/100f,m=mid/100f,b=bass/100f;lowEq=lowEq*.995f+x*.005f;float high=x-lowEq;return clamp(lowEq*(.55f+b*.9f)+x*(.65f+m*.75f)+high*(.45f+t*.9f));}
      float chorus(float x){chBuf[chPos]=x;float l=(float)Math.sin(chorusPhase);chorusPhase+=2*Math.PI*(.18f+chorus*.012f)/SR;if(chorusPhase>Math.PI*2)chorusPhase-=Math.PI*2;float d=18+chorus*.35f+l*(4+chorus*.06f);int di=(chPos-(int)d+SR)%SR;float y=chBuf[di];chPos=(chPos+1)%SR;float m=chorus/100f*.55f;return x*(1-m)+y*m;}
      float flanger(float x){flBuf[flPos]=x;float l=(float)Math.sin(flangePhase);flangePhase+=2*Math.PI*(.08f+flanger*.01f)/SR;if(flangePhase>Math.PI*2)flangePhase-=Math.PI*2;int d=(int)(2+flanger*.12f+l*(1+flanger*.04f));int di=(flPos-d+SR)%SR;float y=flBuf[di];flPos=(flPos+1)%SR;float m=flanger/100f*.65f;return x*(1-m)+y*m;}
      float phaser(float x){float rate=.12f+phaser*.006f,l=(float)Math.sin(phaserState);phaserState+=2*Math.PI*rate/SR;if(phaserState>Math.PI*2)phaserState-=Math.PI*2;float a=.1f+.35f*(l+1)/2f,y=-a*x+z2[0]+a*z1[0];z2[0]=y;z1[0]=x;float m=phaser/100f*.6f;return x*(1-m)+y*m;}
      float delay(float x){int ms=(int)(30+delay/100f*970),d=(int)(ms*SR/1000f);delayBuf[delayPos]=x;int rp=(delayPos-d+delayBuf.length)%delayBuf.length;float y=delayBuf[rp];delayBuf[delayPos]=x+y*(.18f+delay*.006f);delayPos=(delayPos+1)%delayBuf.length;float m=delay/100f*.55f;return x*(1-m)+y*m;}
      float reverb(float x){comb1[c1]=x;comb2[c2]=x;comb3[c3]=x;comb4[c4]=x;float y=(comb1[c1]+comb2[c2]+comb3[c3]+comb4[c4])*.25f;comb1[c1]=x+y*.72f;comb2[c2]=x+y*.69f;comb3[c3]=x+y*.67f;comb4[c4]=x+y*.64f;c1=(c1+1)%comb1.length;c2=(c2+1)%comb2.length;c3=(c3+1)%comb3.length;c4=(c4+1)%comb4.length;float m=reverb/100f*.65f;return x*(1-m)+y*m;}
      float ir(float x){firHist[firPos]=x;float y=0;for(int i=0;i<fir.length;i++)y+=fir[i]*firHist[(firPos-i+fir.length)%fir.length];firPos=(firPos+1)%fir.length;return clamp(y*1.5f);}
      float clamp(float x){return Math.max(-.98f,Math.min(.98f,x));}

      void loopStartRecord(){loopMode=1;loopPos=0;loopLen=0;}
      void loopPlay(){if(loopLen>0){loopMode=2;loopPos=0;}}
      void loopDub(){if(loopLen>0){loopMode=3;loopPos=0;}}
      void loopClear(){loopMode=0;loopPos=0;loopLen=0;}
      void loopProcess(float[] b,int n){
        if(loopMode==1){for(int i=0;i<n;i++){if(loopPos>=loop.length){loopMode=2;loopPos=0;break;}loop[loopPos++]=b[i];loopLen=loopPos;}}
        else if(loopMode==2&&loopLen>0){for(int i=0;i<n;i++){int j=loopPos++%loopLen;b[i]=b[i]*.5f+loop[j]*.5f;}}
        else if(loopMode==3&&loopLen>0){for(int i=0;i<n;i++){int j=loopPos++%loopLen;float y=b[i]*.5f+loop[j]*.5f;b[i]=y;loop[j]=y;}}
      }

      void loadWav(InputStream in)throws Exception{
        DataInputStream d=new DataInputStream(new BufferedInputStream(in));byte[] h=new byte[44];if(d.read(h)!=44)throw new IOException();
        int ch=(h[23]&255)<<8|(h[22]&255),bits=(h[35]&255)<<8|(h[34]&255);if(bits!=16)throw new IOException();
        ByteArrayOutputStream bo=new ByteArrayOutputStream();byte[] buf=new byte[4096];int q;while((q=d.read(buf))>0)bo.write(buf,0,q);byte[] data=bo.toByteArray();
        int samples=Math.min(128,data.length/2/ch);Arrays.fill(fir,0);
        for(int i=0;i<samples;i++){int lo=data[i*2]&255,hi=data[i*2+1];short s=(short)((hi<<8)|lo);fir[i]=s/32768f;}
        float mx=.001f;for(float v:fir)mx=Math.max(mx,Math.abs(v));for(int i=0;i<fir.length;i++)fir[i]/=mx;irLoaded=true;enabled[10]=true;
      }

      void save(SharedPreferences.Editor e){
        e.putFloat("drive",drive).putFloat("amp",ampGain).putFloat("cab",cab).putFloat("chorus",chorus)
         .putFloat("phaser",phaser).putFloat("flanger",flanger).putFloat("delay",delay).putFloat("reverb",reverb)
         .putFloat("tone",tone).putFloat("bass",bass).putFloat("mid",mid).putFloat("treble",treble)
         .putFloat("comp",comp).putFloat("gate",gate).apply();
      }
      void load(SharedPreferences p){
        drive=p.getFloat("drive",drive);ampGain=p.getFloat("amp",ampGain);cab=p.getFloat("cab",cab);
        chorus=p.getFloat("chorus",chorus);phaser=p.getFloat("phaser",phaser);flanger=p.getFloat("flanger",flanger);
        delay=p.getFloat("delay",delay);reverb=p.getFloat("reverb",reverb);tone=p.getFloat("tone",tone);
        bass=p.getFloat("bass",bass);mid=p.getFloat("mid",mid);treble=p.getFloat("treble",treble);
        comp=p.getFloat("comp",comp);gate=p.getFloat("gate",gate);
      }
    }
}
